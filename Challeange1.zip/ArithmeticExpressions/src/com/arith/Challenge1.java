package com.arith;

import java.io.*;
import java.util.*;

public class Challenge1 {

    public static void main(String[] args) {
        String inputFileName = "src/input.txt";
        String outputFileName = "src/outputFile.txt";

        List<String> expressions = readExpressionsFromFile(inputFileName);
        List<String> results = solveExpressions(expressions);
        writeResultsToFile(outputFileName, results);
    }

    
    private static List<String> readExpressionsFromFile(String fileName) {
        List<String> expressions = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                expressions.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return expressions;
    }

   
    private static List<String> solveExpressions(List<String> expressions) {
        List<String> results = new ArrayList<>();
        for (String expression : expressions) {
            try {
                String cleanedExpression = expression.replaceAll("=", "").trim();
                int result = (int) Math.round(evaluate(cleanedExpression)); // Round and cast to int
                results.add(expression.trim() + " " + result);
            } catch (Exception e) {
                results.add(expression.trim() + " Error: " + e.getMessage());
            }
        }
        return results;
    }

    // Writes the results to an output file
    private static void writeResultsToFile(String fileName, List<String> results) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            for (String result : results) {
                bw.write(result);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

   
    private static double evaluate(String expression) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < expression.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;

                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if (eat('[')) { // brackets
                    x = parseExpression();
                    eat(']');
                } else if (eat('{')) { // braces
                    x = parseExpression();
                    eat('}');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(expression.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }
}