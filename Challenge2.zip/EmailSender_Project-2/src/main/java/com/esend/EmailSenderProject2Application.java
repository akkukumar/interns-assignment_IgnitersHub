package com.esend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailSenderProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(EmailSenderProject2Application.class, args);
		System.out.println();
	}

}
