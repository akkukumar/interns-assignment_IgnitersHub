package com.esend.service;

import java.io.InputStream;

public interface EmailService {


	
	void sendEmailWithFile(String to , String subject , String message , InputStream is);
	
	
	
}
