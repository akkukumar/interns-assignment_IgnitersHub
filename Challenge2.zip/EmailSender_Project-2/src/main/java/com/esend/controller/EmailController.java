package com.esend.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.esend.customeresponse.CustomeRespon;
import com.esend.entity.EmailRequest;
import com.esend.service.EmailService;

@RestController
@RequestMapping("api/v1/email") // this is base URL
public class EmailController {

    @Autowired
    private EmailService emailService;



    @PostMapping("/send-with-file")
    public ResponseEntity<CustomeRespon> sendWithFile(
            @RequestPart("req") EmailRequest req,
            @RequestPart("file") MultipartFile file) throws IOException {
        emailService.sendEmailWithFile(req.getTo(), req.getSubject(), req.getMessage(), file.getInputStream());
        return ResponseEntity.ok(CustomeRespon.builder()
                .message("Email sent successfully!")
                .httpststus(HttpStatus.OK)
                .success(true)
                .build());
    }


    
    
}
