package com.esend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailSenderProject2ApplicationTests {
	
	
	@Test
	void emailSendtest()
	{
		
	
	}
     }
